#ifndef _BUTTONCONTROLLER_H_
#define _BUTTONCONTROLLER_H_

#include "controller.h"



void RegisterCallbacks( Controller *ctrl );

#endif // _BUTTONCONTROLLER_H_
