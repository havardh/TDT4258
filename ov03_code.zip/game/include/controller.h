#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

#include "splash.h"
#include "field.h"
#include "cannon.h"
#include "tank.h"
#include "cannonball.h"
#include "tankshot.h"
#include "canvas.h"
#include <stdbool.h>
#include "assert.h"
#include <signal.h>
#include <time.h>
#include <unistd.h>
#include "audio.h"


typedef enum {
	A, B
} Player;

typedef struct {

	bool running;

	Player winner;

	Canvas *canvas;

	Field field;
	Cannon cannon;
	Tank tank;

} Controller;

Controller ControllerNew( Canvas *cavnas );

// Events
void onTick ( Controller* );

void onGameInit( Controller* );
void onGameExit ( Controller* );

void onGameStart ( Controller* );
void onGameOver ( Controller* );

void onRoundStart ( Controller* );
void onRoundOver ( Controller* );

bool onTankMove ( Controller*, int, int );
void onTankFire ( Controller* );
void onTankHit ( Controller* );

bool onCannonAim ( Controller*, int, int );
void onCannonFire ( Controller* );
void onCannonHit ( Controller* );

void ControllerUpdateScore( Controller* );

#endif // _CONTROLLER_H_
