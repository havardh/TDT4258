#ifndef _SPLASH_H_
#define _SPLASH_H_

#include "image.h"
#include "canvas.h"

void showSplashScreen( Canvas* );

#endif // _SPLASH_H_
