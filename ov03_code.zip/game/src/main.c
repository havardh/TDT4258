#include <stdio.h>
#include "controller.h"
#include "screen.h"
#include "canvas.h"
#include <stdbool.h>
//#include "led.h"
#include "button.h"
#include "audio.h"



int main ( void ) {

	printf("Game!\n");

	// Init devices
	ButtonInit();
	LedInit();

	Screen screen = ScreenNew(320, 240);
	Canvas canvas = CanvasNew( &screen );

	// Init game
	Controller ctrl = ControllerNew( &canvas );
	onGameInit( &ctrl );

	// Main loop
	static tick_delay = 0;
	while(ctrl.running) {

		if ( tick_delay++ == 20000 ) {
			tick_delay = 0;
			onTick( &ctrl );
		}

		ButtonPoll();

	}

	onGameExit( &ctrl );

	ButtonDestroy();
	LedDestroy();
	ScreenDestroy( &screen );

	return 0;
}
